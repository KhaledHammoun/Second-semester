package multiton;

public class Jewel implements MinedValuable
{
    @Override
    public double getValue()
    {
        return 12.3;
    }
}
