package multiton;

public class WoodenCoin implements MinedValuable
{
    @Override
    public double getValue()
    {
        return 1.8;
    }
}
