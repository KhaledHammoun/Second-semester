package multiton;

public class Ruby implements MinedValuable
{
    @Override
    public double getValue()
    {
        return 5.45;
    }
}
