package multiton;

public class Diamond implements MinedValuable
{
    @Override
    public double getValue()
    {
        return 7.5;
    }


}
