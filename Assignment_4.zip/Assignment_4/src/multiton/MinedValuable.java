package multiton;

public interface MinedValuable
{
    double getValue();
}
