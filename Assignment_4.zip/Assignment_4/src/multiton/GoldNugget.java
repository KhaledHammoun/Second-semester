package multiton;

public class GoldNugget implements MinedValuable
{
    @Override
    public double getValue()
    {
        return 6.3;
    }
}
