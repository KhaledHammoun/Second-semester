package singleton;

public class ClientMain
{
    public static void main(String[] args)
    {
        Logger.getInstance().log("taka");
    }
}
