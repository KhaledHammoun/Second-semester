package shared;

public enum RequestType
{
  LISTEN, NEWMESSAGE, NEWUSER, ADDFRIEND, NEWFRIEND, ADDUSER, SENDMESSAGE;
}
