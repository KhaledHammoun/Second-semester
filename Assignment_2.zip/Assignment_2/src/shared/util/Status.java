package shared.util;

public enum Status
{
  ACTIVE, INACTIVE;
}
