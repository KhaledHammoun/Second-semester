package client;

import javafx.application.Application;

public class RunClient
{
  public static void main(String[] args)
  {
    Application.launch(StartApp.class);
  }
}
